"""
AI Customer Support Ticket Triage — Dashboard / lightweight API.

Run with:  streamlit run app.py
(Requires train_and_evaluate.py to have been run first, so that
 ../models/*.joblib exist.)

Two things live in this one file, mirroring the brief's "expose through a
small API/dashboard" step:
  1. A Streamlit UI where an agent can paste a ticket and get an instant
     category + urgency prediction with confidence.
  2. Every low-confidence prediction is appended to a review-queue CSV,
     the same file the training pipeline seeds from the test set — so the
     human-review log keeps growing as real tickets are triaged.
"""

import re
import joblib
import pandas as pd
import streamlit as st
from pathlib import Path
from datetime import datetime

MODEL_DIR = Path(__file__).resolve().parent.parent / "models"
OUT_DIR = Path(__file__).resolve().parent.parent / "outputs"
REVIEW_LOG = OUT_DIR / "low_confidence_review_queue.csv"
LOW_CONFIDENCE_THRESHOLD = 0.75

st.set_page_config(page_title="Ticket Triage — Live Demo", layout="centered")


@st.cache_resource
def load_models():
    vectorizer = joblib.load(MODEL_DIR / "vectorizer.joblib")
    category_model = joblib.load(MODEL_DIR / "category_model.joblib")
    urgency_model = joblib.load(MODEL_DIR / "urgency_model.joblib")
    return vectorizer, category_model, urgency_model


def clean_text(text: str) -> str:
    text = str(text).lower()
    text = re.sub(r"http\S+", " ", text)
    text = re.sub(r"[^a-z0-9\s#$%]", " ", text)
    text = re.sub(r"\s+", " ", text).strip()
    return text


vectorizer, category_model, urgency_model = load_models()

st.title("🎫 AI Customer Support Ticket Triage")
st.caption("Paste a ticket below to see the predicted category, urgency, and routing decision.")

with st.form("ticket_form"):
    subject = st.text_input("Subject", placeholder="e.g. App crashes on startup")
    body = st.text_area("Body", height=140, placeholder="Describe the issue in the customer's own words...")
    submitted = st.form_submit_button("Triage Ticket")

if submitted:
    if not subject.strip() and not body.strip():
        st.warning("Enter a subject or body to triage.")
    else:
        text = clean_text(subject + ". " + body)
        X = vectorizer.transform([text])

        cat_pred = category_model.predict(X)[0]
        cat_conf = category_model.predict_proba(X).max()

        urg_pred = urgency_model.predict(X)[0]
        urg_conf = urgency_model.predict_proba(X).max()

        combined_conf = min(cat_conf, urg_conf)
        needs_review = combined_conf < LOW_CONFIDENCE_THRESHOLD

        queue_map = {
            "Billing": "Billing Support Queue",
            "Technical": "Technical Support Queue (Tier 2)",
            "Account": "Account & Access Queue",
            "Product": "Product Team Queue",
        }
        urgency_color = {"Critical": "🔴", "High": "🟠", "Medium": "🟡", "Low": "🟢"}

        st.divider()
        c1, c2 = st.columns(2)
        c1.metric("Predicted Category", cat_pred, f"{cat_conf*100:.1f}% confidence")
        c2.metric("Predicted Urgency", f"{urgency_color[urg_pred]} {urg_pred}", f"{urg_conf*100:.1f}% confidence")

        st.info(f"**Routed to:** {queue_map[cat_pred]}")

        if needs_review:
            st.warning(
                f"⚠️ Low confidence ({combined_conf*100:.1f}%) — flagged for human review "
                f"before final routing."
            )
            # Log to the review queue CSV
            log_row = pd.DataFrame([{
                "ticket_id": f"LIVE-{datetime.now().strftime('%Y%m%d%H%M%S')}",
                "subject": subject, "body": body,
                "category": None, "urgency": None,
                "predicted_category": cat_pred, "category_confidence": round(cat_conf, 3),
                "predicted_urgency": urg_pred, "urgency_confidence": round(urg_conf, 3),
            }])
            if REVIEW_LOG.exists():
                log_row.to_csv(REVIEW_LOG, mode="a", header=False, index=False)
            else:
                log_row.to_csv(REVIEW_LOG, index=False)
        else:
            st.success("✅ High confidence — auto-routed, no human review needed.")

st.divider()

# ---------------------------------------------------------------
# Model performance + review queue (sidebar)
# ---------------------------------------------------------------
st.sidebar.header("Model Performance")
try:
    import json
    with open(OUT_DIR / "model_summary.json") as f:
        summary = json.load(f)
    st.sidebar.metric("Category Macro F1", summary["category_macro_f1"])
    st.sidebar.metric("Urgency Macro F1", summary["urgency_macro_f1"])
    st.sidebar.metric("% Flagged for Review", f"{summary['pct_flagged_for_review']}%")
except FileNotFoundError:
    st.sidebar.info("Run train_and_evaluate.py to populate model metrics.")

st.sidebar.header("Human Review Queue")
if REVIEW_LOG.exists():
    review_df = pd.read_csv(REVIEW_LOG)
    st.sidebar.write(f"{len(review_df)} tickets awaiting review")
    st.sidebar.dataframe(review_df.tail(10)[["ticket_id", "predicted_category", "predicted_urgency"]],
                          use_container_width=True, hide_index=True)
else:
    st.sidebar.write("No tickets in the review queue yet.")
