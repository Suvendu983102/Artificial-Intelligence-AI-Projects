"""
AI Customer Support Ticket Triage — training & evaluation pipeline.

Steps:
 1. Load historical ticket text + category + urgency + resolution data
 2. Clean text; combine subject+body into one field
 3. TF-IDF text features (with a note on swapping in sentence embeddings)
 4. Train a multiclass CATEGORY classifier and a separate URGENCY classifier
 5. Evaluate both with F1, confusion matrix, and per-class precision/recall
 6. Save models + vectorizer to disk for the dashboard/API to load
 7. Flag low-confidence predictions on a held-out slice for human review

Run: python train_and_evaluate.py
"""

import re
import json
import joblib
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from pathlib import Path

from sklearn.model_selection import train_test_split
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import (classification_report, confusion_matrix,
                              f1_score, ConfusionMatrixDisplay)

DATA_DIR = Path("/home/claude/ticket_triage/data")
OUT_DIR = Path("/home/claude/ticket_triage/outputs")
MODEL_DIR = Path("/home/claude/ticket_triage/models")
OUT_DIR.mkdir(exist_ok=True)
MODEL_DIR.mkdir(exist_ok=True)

RANDOM_STATE = 42
LOW_CONFIDENCE_THRESHOLD = 0.75  # predictions below this get flagged for human review

# ---------------------------------------------------------------
# 1. LOAD
# ---------------------------------------------------------------
df = pd.read_csv(DATA_DIR / "tickets.csv")
print(f"Loaded {len(df):,} tickets")

# ---------------------------------------------------------------
# 2. CLEAN TEXT
# ---------------------------------------------------------------
def clean_text(text: str) -> str:
    text = str(text).lower()
    text = re.sub(r"http\S+", " ", text)          # strip URLs
    text = re.sub(r"[^a-z0-9\s#$%]", " ", text)    # keep basic punctuation that carries signal ($ amounts, # ids)
    text = re.sub(r"\s+", " ", text).strip()
    return text

df["text"] = (df["subject"].fillna("") + ". " + df["body"].fillna("")).apply(clean_text)
df = df.dropna(subset=["category", "urgency"])
df = df[df["text"].str.len() > 0].reset_index(drop=True)

print(f"After cleaning: {len(df):,} usable tickets")

# ---------------------------------------------------------------
# 3. TRAIN / TEST SPLIT (stratified on category so rare classes stay represented)
# ---------------------------------------------------------------
train_df, test_df = train_test_split(
    df, test_size=0.2, random_state=RANDOM_STATE, stratify=df["category"]
)
print(f"Train: {len(train_df):,} | Test: {len(test_df):,}")

# ---------------------------------------------------------------
# 4. TEXT FEATURES — TF-IDF
# ---------------------------------------------------------------
# Note: for a production system, swapping this TfidfVectorizer for sentence
# embeddings (e.g. `sentence-transformers` all-MiniLM-L6-v2) is a drop-in
# upgrade — encode text to vectors, then feed those vectors to the same
# classifiers below. TF-IDF is used here for a fast, dependency-light,
# fully offline baseline that is still strong for short support tickets.
vectorizer = TfidfVectorizer(
    max_features=5000, ngram_range=(1, 2), stop_words="english", min_df=2
)
X_train = vectorizer.fit_transform(train_df["text"])
X_test = vectorizer.transform(test_df["text"])

# ---------------------------------------------------------------
# 5. MODEL 1 — CATEGORY CLASSIFIER (multiclass)
# ---------------------------------------------------------------
y_train_cat = train_df["category"]
y_test_cat = test_df["category"]

category_model = LogisticRegression(max_iter=1000, class_weight="balanced", random_state=RANDOM_STATE)
category_model.fit(X_train, y_train_cat)

cat_pred = category_model.predict(X_test)
cat_proba = category_model.predict_proba(X_test)
cat_confidence = cat_proba.max(axis=1)

cat_f1_macro = f1_score(y_test_cat, cat_pred, average="macro")
cat_f1_weighted = f1_score(y_test_cat, cat_pred, average="weighted")
print(f"\n=== CATEGORY MODEL ===")
print(f"Macro F1: {cat_f1_macro:.3f} | Weighted F1: {cat_f1_weighted:.3f}")
print(classification_report(y_test_cat, cat_pred))

cat_report = classification_report(y_test_cat, cat_pred, output_dict=True)
pd.DataFrame(cat_report).T.to_csv(OUT_DIR / "category_classification_report.csv")

# Confusion matrix
fig, ax = plt.subplots(figsize=(6, 5))
ConfusionMatrixDisplay.from_predictions(
    y_test_cat, cat_pred, labels=category_model.classes_, cmap="Blues", ax=ax, colorbar=False
)
ax.set_title("Category Classifier — Confusion Matrix")
plt.tight_layout()
plt.savefig(OUT_DIR / "category_confusion_matrix.png", dpi=150)
plt.close()

# ---------------------------------------------------------------
# 6. MODEL 2 — URGENCY CLASSIFIER (separate multiclass model)
# ---------------------------------------------------------------
y_train_urg = train_df["urgency"]
y_test_urg = test_df["urgency"]

urgency_model = LogisticRegression(max_iter=1000, class_weight="balanced", random_state=RANDOM_STATE)
urgency_model.fit(X_train, y_train_urg)

urg_pred = urgency_model.predict(X_test)
urg_proba = urgency_model.predict_proba(X_test)
urg_confidence = urg_proba.max(axis=1)

urg_f1_macro = f1_score(y_test_urg, urg_pred, average="macro")
urg_f1_weighted = f1_score(y_test_urg, urg_pred, average="weighted")
print(f"\n=== URGENCY MODEL ===")
print(f"Macro F1: {urg_f1_macro:.3f} | Weighted F1: {urg_f1_weighted:.3f}")
print(classification_report(y_test_urg, urg_pred))

urg_report = classification_report(y_test_urg, urg_pred, output_dict=True)
pd.DataFrame(urg_report).T.to_csv(OUT_DIR / "urgency_classification_report.csv")

urgency_order = ["Low", "Medium", "High", "Critical"]
fig, ax = plt.subplots(figsize=(6, 5))
ConfusionMatrixDisplay.from_predictions(
    y_test_urg, urg_pred, labels=urgency_order, cmap="Oranges", ax=ax, colorbar=False
)
ax.set_title("Urgency Classifier — Confusion Matrix")
plt.tight_layout()
plt.savefig(OUT_DIR / "urgency_confusion_matrix.png", dpi=150)
plt.close()

# ---------------------------------------------------------------
# 7. PER-CLASS PRECISION/RECALL CHART (both models side by side)
# ---------------------------------------------------------------
fig, axes = plt.subplots(1, 2, figsize=(13, 5))

cat_df = pd.DataFrame(cat_report).T.loc[category_model.classes_, ["precision", "recall", "f1-score"]]
cat_df.plot(kind="bar", ax=axes[0], color=["#065A82", "#3FBFA6", "#D9704F"])
axes[0].set_title("Category Model — Precision / Recall / F1 by Class")
axes[0].set_ylim(0, 1)
axes[0].legend(loc="lower right", fontsize=9)
axes[0].tick_params(axis="x", rotation=20)

urg_df = pd.DataFrame(urg_report).T.loc[urgency_order, ["precision", "recall", "f1-score"]]
urg_df.plot(kind="bar", ax=axes[1], color=["#065A82", "#3FBFA6", "#D9704F"])
axes[1].set_title("Urgency Model — Precision / Recall / F1 by Class")
axes[1].set_ylim(0, 1)
axes[1].legend(loc="lower right", fontsize=9)
axes[1].tick_params(axis="x", rotation=20)

plt.tight_layout()
plt.savefig(OUT_DIR / "precision_recall_by_class.png", dpi=150)
plt.close()

# ---------------------------------------------------------------
# 8. LOW-CONFIDENCE PREDICTIONS → HUMAN REVIEW QUEUE
# ---------------------------------------------------------------
combined_confidence = np.minimum(cat_confidence, urg_confidence)
review_mask = combined_confidence < LOW_CONFIDENCE_THRESHOLD
review_queue = test_df.loc[review_mask, ["ticket_id", "subject", "body", "category", "urgency"]].copy()
review_queue["predicted_category"] = cat_pred[review_mask]
review_queue["category_confidence"] = cat_confidence[review_mask].round(3)
review_queue["predicted_urgency"] = urg_pred[review_mask]
review_queue["urgency_confidence"] = urg_confidence[review_mask].round(3)
review_queue.to_csv(OUT_DIR / "low_confidence_review_queue.csv", index=False)

print(f"\n{len(review_queue)} of {len(test_df)} test tickets "
      f"({len(review_queue)/len(test_df)*100:.1f}%) flagged for human review "
      f"(confidence < {LOW_CONFIDENCE_THRESHOLD})")

# ---------------------------------------------------------------
# 9. SAVE MODELS + VECTORIZER FOR THE DASHBOARD/API
# ---------------------------------------------------------------
joblib.dump(vectorizer, MODEL_DIR / "vectorizer.joblib")
joblib.dump(category_model, MODEL_DIR / "category_model.joblib")
joblib.dump(urgency_model, MODEL_DIR / "urgency_model.joblib")

summary = {
    "category_macro_f1": round(cat_f1_macro, 3),
    "category_weighted_f1": round(cat_f1_weighted, 3),
    "urgency_macro_f1": round(urg_f1_macro, 3),
    "urgency_weighted_f1": round(urg_f1_weighted, 3),
    "low_confidence_threshold": LOW_CONFIDENCE_THRESHOLD,
    "pct_flagged_for_review": round(len(review_queue) / len(test_df) * 100, 1),
    "train_size": len(train_df),
    "test_size": len(test_df),
}
with open(OUT_DIR / "model_summary.json", "w") as f:
    json.dump(summary, f, indent=2)

print("\nModels saved to:", MODEL_DIR)
print("Evaluation outputs saved to:", OUT_DIR)
print(json.dumps(summary, indent=2))
