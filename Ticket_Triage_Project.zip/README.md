# AI Customer Support Ticket Triage

**Capstone Project — Mindenious Edutech Data Science Program**

## Objective
Build an AI system that reads incoming support tickets, predicts their category and urgency, and routes them to the appropriate support queue.

## Project Structure
```
ticket_triage/
├── data/
│   ├── generate_tickets.py     # synthetic historical ticket generator
│   └── tickets.csv
├── notebooks/
│   └── train_and_evaluate.py   # cleaning -> TF-IDF -> 2 models -> evaluation -> review queue
├── dashboard/
│   └── app.py                  # Streamlit triage UI ("small API/dashboard")
├── models/                     # saved vectorizer + trained models (joblib)
│   ├── vectorizer.joblib
│   ├── category_model.joblib
│   └── urgency_model.joblib
├── outputs/
│   ├── category_classification_report.csv
│   ├── urgency_classification_report.csv
│   ├── category_confusion_matrix.png
│   ├── urgency_confusion_matrix.png
│   ├── precision_recall_by_class.png
│   ├── low_confidence_review_queue.csv
│   └── model_summary.json
├── requirements.txt
└── README.md
```

## How to Run
```bash
pip install -r requirements.txt

# 1. Generate the synthetic historical ticket dataset
python data/generate_tickets.py

# 2. Clean text, train both models, evaluate, save to /models and /outputs
python notebooks/train_and_evaluate.py

# 3. Launch the triage dashboard
streamlit run dashboard/app.py
```

## Approach (mapped to the brief)
1. **Collect historical data** — `generate_tickets.py` produces ticket text (subject + body), category, urgency, resolution time, and customer tier. Deliberately includes short/low-signal tickets (~5%) and mislabeled categories (~3%) to mimic real historical noise.
2. **Clean text and create labels** — lowercased, URL-stripped, punctuation-normalized (keeping `$`/`#` since they carry billing/order signal); labels are the four categories (Billing, Technical, Account, Product).
3. **Text features** — TF-IDF (unigrams + bigrams, 5,000 features, English stop words removed). The pipeline is written so swapping in sentence embeddings (e.g. `sentence-transformers`) is a drop-in replacement — encode text to vectors, feed the same vectors to the same classifiers.
4. **Two separate models** — a multiclass `LogisticRegression` (class-balanced) for **category**, and an independently trained one for **urgency**, exactly as the brief asks for "a separate urgency model."
5. **Evaluation** — macro/weighted F1, full `classification_report`, and a confusion matrix + per-class precision/recall/F1 chart for each model (see `/outputs`).
6. **Dashboard + human-review logging** — the Streamlit app takes a pasted ticket, shows the predicted category/urgency with confidence and the routed queue, and any prediction below a 0.75 confidence threshold is both flagged in the UI and appended to `low_confidence_review_queue.csv` for a human to check.

## Results (on the generated sample data)
| Model | Macro F1 | Weighted F1 |
|---|---|---|
| Category (Billing/Technical/Account/Product) | 0.961 | 0.961 |
| Urgency (Low/Medium/High/Critical) | 0.856 | 0.857 |

- Category is the easier task — the four categories use distinct vocabulary (billing amounts/invoices vs. login/crash language vs. account/team language).
- Urgency is harder, as expected — urgency depends more on tone and severity words than fixed vocabulary, and real-world label noise (people disagreeing on what's "High" vs "Critical") caps how high this can realistically go.
- **11.5%** of test tickets fall below the 0.75 confidence threshold and are routed to human review rather than auto-routed — this threshold is a tunable trade-off between automation rate and error tolerance.

## Data Note
As with the other capstone project, no proprietary ticket data was provided, so this uses a **synthetically generated dataset** (`data/generate_tickets.py`) built from realistic ticket templates per category/urgency combination, with intentional noise (short tickets, label drift, occasional mislabeling) so every step in the brief — cleaning, modeling, and the human-review safety net — is genuinely exercised. To adapt this to real support data (e.g. a Zendesk/Freshdesk export), replace `tickets.csv` with matching columns (`subject`, `body`, `category`, `urgency`) or adjust the column mapping in `train_and_evaluate.py`.

## Suggested Stack (per brief)
- **Python** (pandas, scikit-learn) for cleaning, feature extraction, and modeling
- **TF-IDF** (or sentence embeddings as a swap-in upgrade) for text features
- **Streamlit** for the triage dashboard / lightweight API
- **Git/GitHub** for version control
