"""
Synthetic AI Customer Support Ticket dataset generator.

Produces a realistic (but synthetic) set of support tickets with:
  - free-text subject + body
  - category label (Billing, Technical, Account, Product)
  - urgency label (Low, Medium, High, Critical)
  - resolution_hours (historical resolution time, for context/reporting)

Deliberately includes noisy/ambiguous tickets (short text, mixed-signal wording,
typos) so the downstream cleaning + modeling steps are genuinely exercised.

Run: python generate_tickets.py
Output: ../data/tickets.csv
"""

import random
import numpy as np
import pandas as pd
from faker import Faker

random.seed(7)
np.random.seed(7)
fake = Faker()
Faker.seed(7)

N_TICKETS = 6000

CATEGORIES = ["Billing", "Technical", "Account", "Product"]

# ---------------------------------------------------------------
# Template bank: (subject templates, body templates) per category,
# with a rough natural urgency skew per template (some phrasing reads
# more urgent than others, mimicking real ticket language).
# ---------------------------------------------------------------
TEMPLATES = {
    "Billing": [
        ("Double charge on my last invoice",
         "I was charged twice for order #{order}. My card statement shows two identical charges of ${amount} on {date}. Please refund the duplicate.",
         "Medium"),
        ("Refund never received",
         "I cancelled my subscription on {date} and was told I'd get a refund within 5 business days. It has been two weeks and I still haven't received ${amount}.",
         "High"),
        ("Question about invoice line item",
         "Can someone explain the ${amount} charge labeled 'service fee' on invoice #{order}? I don't recognize this line item.",
         "Low"),
        ("Urgent: card charged after cancellation",
         "I cancelled my plan last month but was just charged ${amount} again today. This needs to be fixed and refunded immediately, I'm considering a chargeback.",
         "Critical"),
        ("Update billing address",
         "I need to update the billing address on file for account {order}. Can you point me to where I do this?",
         "Low"),
        ("Annual plan discount not applied",
         "I signed up for the annual plan expecting a 20% discount but was billed the full monthly rate x12. Invoice #{order}.",
         "Medium"),
    ],
    "Technical": [
        ("App crashes on startup",
         "Since updating to the latest version, the app crashes immediately on launch on my {device}. I've tried reinstalling but the issue persists.",
         "High"),
        ("Cannot upload files",
         "File uploads have been failing with a generic error for the past hour. I need this working for a deadline today.",
         "High"),
        ("Site is completely down",
         "The entire dashboard is unreachable, getting a 502 error. This is affecting my whole team and we cannot work. Please escalate.",
         "Critical"),
        ("Minor UI glitch on settings page",
         "The toggle switch on the notifications settings page overlaps the label text slightly on {device}. Not urgent, just flagging.",
         "Low"),
        ("Slow loading times",
         "Pages have been taking 10-15 seconds to load over the last two days. It's annoying but I can still get work done.",
         "Medium"),
        ("API returning 500 errors intermittently",
         "Our integration is getting intermittent 500 errors from the /v1/orders endpoint, roughly 1 in 20 requests. Logs attached.",
         "High"),
        ("Two-factor login not sending code",
         "I'm locked out because the 2FA text message never arrives. I've requested it 5 times in the last 10 minutes and need access now.",
         "Critical"),
    ],
    "Account": [
        ("Can't reset password",
         "The password reset link in the email leads to an expired token error every time I request a new one.",
         "High"),
        ("How do I add a teammate to my account",
         "I'd like to invite a colleague to my workspace {order}. Where do I manage team members and permissions?",
         "Low"),
        ("Account suspended without explanation",
         "My account {order} was suspended overnight with no email explanation. I have paying customers relying on this, please restore access urgently.",
         "Critical"),
        ("Change email address on file",
         "I need to change the email associated with my account from an old work address to my personal one.",
         "Low"),
        ("Merge two duplicate accounts",
         "I accidentally created two accounts with different emails, {order} and a second one. Could you merge them?",
         "Medium"),
        ("Login works on phone but not laptop",
         "I can log in fine on my {device} but get an 'invalid session' error every time on my laptop browser.",
         "Medium"),
    ],
    "Product": [
        ("Feature request: dark mode",
         "Would love to see a dark mode option in a future release. Not urgent, just a nice-to-have.",
         "Low"),
        ("Export to CSV missing columns",
         "When I export my report to CSV, the 'region' and 'margin' columns are missing compared to the on-screen table.",
         "Medium"),
        ("Confused about plan limits",
         "I'm not sure how many seats are included in the {plan} plan versus the {plan2} plan. Could you clarify the differences?",
         "Low"),
        ("Bulk import limit too low",
         "The bulk import caps at 500 rows per file, which is a major blocker for our onboarding of 10,000 records this week.",
         "High"),
        ("Integration with third-party tool",
         "Does the product support a native integration with {tool}, or would we need to build a custom connector?",
         "Low"),
        ("Data discrepancy between dashboard and export",
         "The revenue number shown on the dashboard doesn't match the total in the exported report for the same date range. This is blocking our month-end close.",
         "High"),
    ],
}

DEVICES = ["iPhone 14", "Samsung Galaxy S22", "Windows 11 laptop", "MacBook Pro", "iPad"]
TOOLS = ["Slack", "Salesforce", "HubSpot", "Zapier", "QuickBooks"]
PLANS = ["Starter", "Growth", "Pro", "Enterprise"]

URGENCY_LEVELS = ["Low", "Medium", "High", "Critical"]
# noise: probability the realized urgency drifts one step from the template's natural level
DRIFT_PROB = 0.18


def drift_urgency(natural):
    idx = URGENCY_LEVELS.index(natural)
    if random.random() < DRIFT_PROB:
        step = random.choice([-1, 1])
        idx = min(max(idx + step, 0), len(URGENCY_LEVELS) - 1)
    return URGENCY_LEVELS[idx]


rows = []
for i in range(N_TICKETS):
    category = random.choice(CATEGORIES)
    subject_t, body_t, natural_urgency = random.choice(TEMPLATES[category])

    fmt = dict(
        order=fake.bothify(text="ORD-#####"),
        amount=round(np.random.uniform(9, 499), 2),
        date=fake.date_between(start_date="-90d", end_date="today").strftime("%b %d"),
        device=random.choice(DEVICES),
        tool=random.choice(TOOLS),
        plan=random.choice(PLANS),
        plan2=random.choice(PLANS),
    )
    subject = subject_t.format(**fmt)
    body = body_t.format(**fmt)

    urgency = drift_urgency(natural_urgency)

    # ~5% very short / low-signal tickets (hard cases for the model)
    if random.random() < 0.05:
        body = random.choice(["Please help.", "Not working.", "??", "See above.", "Any update on this?"])

    # ~3% mislabeled category noise (simulates historical mislabeling in real ticket systems)
    stated_category = category
    if random.random() < 0.03:
        stated_category = random.choice([c for c in CATEGORIES if c != category])

    resolution_hours = {
        "Critical": np.random.gamma(2, 1.5),
        "High": np.random.gamma(3, 3),
        "Medium": np.random.gamma(4, 6),
        "Low": np.random.gamma(5, 10),
    }[urgency]

    rows.append({
        "ticket_id": f"TCK{i+1:06d}",
        "created_at": fake.date_time_between(start_date="-180d", end_date="now"),
        "subject": subject,
        "body": body,
        "category": stated_category,
        "urgency": urgency,
        "resolution_hours": round(resolution_hours, 1),
        "customer_tier": random.choices(["Free", "Pro", "Enterprise"], weights=[0.5, 0.35, 0.15])[0],
    })

tickets_df = pd.DataFrame(rows)
tickets_df.to_csv("/home/claude/ticket_triage/data/tickets.csv", index=False)

print(f"Generated {len(tickets_df)} tickets")
print(tickets_df["category"].value_counts())
print(tickets_df["urgency"].value_counts())
