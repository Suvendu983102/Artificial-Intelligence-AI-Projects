"""
AI Document Risk & Compliance Classifier — Dashboard.

Run with:  streamlit run app.py
(Requires train_classifier.py to have been run first.)

Shows:
  - Upload a PDF -> predicted risk category + confidence
  - Explainability: top contributing terms for the predicted class, plus the
    nearest similar training documents (TF-IDF cosine similarity)
  - A flagged-documents view: every test document below the confidence
    threshold, for manual review
"""

import re
import json
import joblib
import numpy as np
import pandas as pd
import streamlit as st
from pathlib import Path
from pypdf import PdfReader
from sklearn.metrics.pairwise import cosine_similarity

MODEL_DIR = Path(__file__).resolve().parent.parent / "models"
OUT_DIR = Path(__file__).resolve().parent.parent / "outputs"
DATA_DIR = Path(__file__).resolve().parent.parent / "data"
LOW_CONFIDENCE_THRESHOLD = 0.55

st.set_page_config(page_title="Document Risk & Compliance Classifier", layout="wide")


@st.cache_resource
def load_models():
    vectorizer = joblib.load(MODEL_DIR / "vectorizer.joblib")
    model = joblib.load(MODEL_DIR / "classifier.joblib")
    return vectorizer, model


@st.cache_data
def load_reference_data():
    labels_df = pd.read_csv(OUT_DIR / "documents_with_text.csv")
    with open(OUT_DIR / "top_terms_per_class.json") as f:
        top_terms = json.load(f)
    return labels_df, top_terms


def clean_text(text: str) -> str:
    text = text.lower()
    text = re.sub(r"[\r\n]+", " ", text)
    text = re.sub(r"[^a-z0-9\s.,%$]", " ", text)
    text = re.sub(r"\s+", " ", text).strip()
    return text


def extract_pdf_text(file) -> str:
    reader = PdfReader(file)
    return "\n".join(page.extract_text() or "" for page in reader.pages)


vectorizer, model = load_models()
labels_df, top_terms = load_reference_data()

# Pre-vectorize the reference corpus once for nearest-neighbor lookups
reference_vectors = vectorizer.transform(labels_df["text"].fillna("")) if "text" in labels_df.columns else None

st.title("📄 AI Document Risk & Compliance Classifier")
st.caption("Upload a business document to classify its risk category, with explainability and manual-review flagging.")

tab1, tab2 = st.tabs(["🔍 Classify a Document", "⚠️ Manual Review Queue"])

# ---------------------------------------------------------------
# TAB 1 — Classify a document
# ---------------------------------------------------------------
with tab1:
    uploaded = st.file_uploader("Upload a PDF document", type=["pdf"])

    if uploaded:
        raw_text = extract_pdf_text(uploaded)
        text = clean_text(raw_text)

        if len(text) < 20:
            st.warning("Couldn't extract enough text from this PDF to classify it.")
        else:
            X = vectorizer.transform([text])
            pred = model.predict(X)[0]
            proba = model.predict_proba(X)[0]
            confidence = proba.max()

            needs_review = confidence < LOW_CONFIDENCE_THRESHOLD

            c1, c2 = st.columns(2)
            c1.metric("Predicted Category", pred, f"{confidence*100:.1f}% confidence")
            if needs_review:
                c2.warning("⚠️ Below confidence threshold — flagged for manual review")
            else:
                c2.success("✅ High confidence — auto-classified")

            st.subheader("Confidence by Category")
            proba_df = pd.DataFrame({"category": model.classes_, "confidence": proba}).sort_values(
                "confidence", ascending=False)
            st.bar_chart(proba_df.set_index("category"))

            st.subheader("🔎 Explainability")
            ecol1, ecol2 = st.columns(2)
            with ecol1:
                st.markdown(f"**Top terms typically driving a '{pred}' classification:**")
                st.write(", ".join(top_terms.get(pred, [])[:10]))
            with ecol2:
                if reference_vectors is not None:
                    sims = cosine_similarity(X, reference_vectors).flatten()
                    top_idx = np.argsort(sims)[-3:][::-1]
                    neighbors = labels_df.iloc[top_idx][["doc_id", "true_category", "doc_type"]].copy()
                    neighbors["similarity"] = sims[top_idx].round(3)
                    st.markdown("**Nearest similar documents:**")
                    st.dataframe(neighbors, hide_index=True, use_container_width=True)

            with st.expander("View extracted text"):
                st.text(raw_text[:2000])
    else:
        st.info("Upload a PDF to see its predicted risk category, confidence breakdown, and explainability.")

# ---------------------------------------------------------------
# TAB 2 — Manual review queue
# ---------------------------------------------------------------
with tab2:
    try:
        review_df = pd.read_csv(OUT_DIR / "manual_review_queue.csv")
        all_preds_df = pd.read_csv(OUT_DIR / "all_predictions.csv")

        with open(OUT_DIR / "model_summary.json") as f:
            summary = json.load(f)

        c1, c2, c3 = st.columns(3)
        c1.metric("Macro F1", summary["macro_f1"])
        c2.metric("Flagged for Review", f"{summary['pct_flagged_for_review']}%")
        c3.metric("Total Test Documents", summary["test_size"])

        st.subheader("Documents Flagged for Manual Review")
        if len(review_df):
            st.dataframe(review_df, use_container_width=True, hide_index=True)
        else:
            st.success("No documents currently flagged — all predictions are above the confidence threshold.")

        st.subheader("All Test-Set Predictions")
        st.dataframe(
            all_preds_df[["doc_id", "doc_type", "true_category", "predicted_category", "confidence", "flagged_for_review"]],
            use_container_width=True, hide_index=True,
        )
    except FileNotFoundError:
        st.info("Run train_classifier.py first to populate the review queue.")
