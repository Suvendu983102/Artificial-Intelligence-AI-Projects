"""
Synthetic Business Document generator — produces REAL PDF files (not just text)
so the downstream pipeline genuinely exercises "extract text from PDFs" per the brief.

Categories (risk/compliance classes):
  - Low Risk        : marketing materials, newsletters, public announcements
  - Medium Risk      : standard vendor agreements, HR policies, internal memos
  - High Risk        : financial audit reports, data-incident reports, legal disputes
  - Critical/Regulatory: regulatory filings, AML/KYC reports, breach notifications

Run: python generate_documents.py
Output: ../data/pdfs/DOC_####.pdf  (one per document)
        ../data/labels.csv          (doc_id, true_category, doc_type)
"""

import random
from pathlib import Path
import pandas as pd
from faker import Faker
from reportlab.lib.pagesizes import letter
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer
from reportlab.lib.styles import getSampleStyleSheet
from reportlab.lib.units import inch

random.seed(21)
Faker.seed(21)
fake = Faker()

N_DOCS = 500
PDF_DIR = Path("/home/claude/doc_risk_classifier/data/pdfs")
PDF_DIR.mkdir(parents=True, exist_ok=True)

styles = getSampleStyleSheet()

# ---------------------------------------------------------------
# Category -> (doc_type, sentence bank). Sentences are combined randomly
# per document so vocabulary overlaps realistically but categories stay
# separable — the same way real business documents do.
# ---------------------------------------------------------------
SHARED_BOILERPLATE = [
    "This document is intended for internal review and distribution purposes only.",
    "Please direct any questions regarding this document to the relevant department contact.",
    "This document was prepared on behalf of the company and reflects information as of the stated date.",
    "All recipients are expected to handle this document in accordance with company guidelines.",
    "This document may be updated periodically to reflect changes in policy or circumstance.",
]

CATEGORY_CONTENT = {
    "Low Risk": {
        "doc_types": ["Marketing Newsletter", "Company Announcement", "Event Invitation", "Press Release"],
        "sentences": [
            "We are excited to announce the launch of our new product line this quarter.",
            "Join us for the annual company town hall event next month.",
            "Our team had a fantastic time at the industry conference last week.",
            "Please find attached the latest edition of our company newsletter.",
            "We are proud to celebrate another successful year of growth and community engagement.",
            "The marketing team has prepared new promotional materials for the upcoming campaign.",
            "Customer satisfaction scores continue to trend upward according to recent surveys.",
            "We welcome our newest team members who joined the company this month.",
            "The office holiday party will be held on the rooftop terrace this year.",
            "Our social media engagement has grown significantly over the past quarter.",
        ],
    },
    "Medium Risk": {
        "doc_types": ["Vendor Agreement", "HR Policy Document", "Internal Memo", "Standard NDA"],
        "sentences": [
            "This agreement outlines the standard terms of service between the vendor and the company.",
            "Employees are required to complete the annual compliance training by the end of the quarter.",
            "This memo provides an update on the current status of the ongoing internal project.",
            "The parties agree to keep the terms of this agreement confidential for a period of two years.",
            "All expense reports must be submitted with supporting receipts within 30 days.",
            "The updated remote work policy applies to all full-time employees effective immediately.",
            "This non-disclosure agreement governs the exchange of proprietary information between both parties.",
            "The vendor shall provide services in accordance with the attached statement of work.",
            "Employee performance reviews will be conducted on a semi-annual basis going forward.",
            "This document outlines standard onboarding procedures for new hires in the department.",
        ],
    },
    "High Risk": {
        "doc_types": ["Financial Audit Report", "Data Incident Report", "Legal Dispute Summary", "Executive Compensation Agreement"],
        "sentences": [
            "The audit identified material weaknesses in the internal control environment over financial reporting.",
            "A data security incident was detected affecting customer records on the specified date.",
            "The company is currently party to ongoing litigation regarding an alleged breach of contract.",
            "This report summarizes discrepancies found in the quarterly financial statements requiring immediate attention.",
            "Unauthorized access to internal systems was identified and has been escalated to the security team.",
            "The executive compensation package includes performance-based equity grants subject to board approval.",
            "Legal counsel has advised that the pending dispute carries significant financial and reputational exposure.",
            "The forensic investigation revealed irregularities in vendor payment approvals over the past fiscal year.",
            "This settlement agreement resolves all claims arising from the aforementioned contract dispute.",
            "The incident response team has contained the breach and is conducting a full impact assessment.",
        ],
    },
    "Critical/Regulatory": {
        "doc_types": ["Regulatory Filing", "AML/KYC Compliance Report", "Breach Notification", "Government Investigation Response"],
        "sentences": [
            "This filing is submitted in accordance with applicable securities regulations and disclosure requirements.",
            "The anti-money laundering review flagged several transactions requiring enhanced due diligence.",
            "Pursuant to data protection regulations, affected individuals are being notified of this breach within the required timeframe.",
            "This document constitutes the company's formal response to the regulatory inquiry received on the stated date.",
            "Know-your-customer verification procedures were found to be non-compliant with current regulatory standards.",
            "The company is required to report this incident to the relevant supervisory authority within 72 hours.",
            "This compliance report details remediation steps taken in response to the regulatory examination findings.",
            "Failure to comply with these regulatory requirements may result in significant financial penalties.",
            "The whistleblower complaint has been escalated to the compliance department for formal investigation.",
            "This notification is issued in compliance with mandatory breach disclosure obligations under applicable law.",
        ],
    },
}

rows = []
doc_id = 1

for _ in range(N_DOCS):
    category = random.choice(list(CATEGORY_CONTENT.keys()))
    content = CATEGORY_CONTENT[category]
    doc_type = random.choice(content["doc_types"])

    # ~15% of documents are genuinely ambiguous: sentences drawn roughly evenly
    # from TWO categories, labeled by whichever is dominant (mimicking a real
    # document that touches two risk themes, which a human labeler would still
    # have to make a judgment call on). This is what should produce genuine
    # low-confidence predictions later, not just an easy 4-way split.
    is_ambiguous = random.random() < 0.15
    secondary_category = None
    if is_ambiguous:
        secondary_category = random.choice([c for c in CATEGORY_CONTENT if c != category])
        n_primary = random.randint(2, 3)
        n_secondary = random.randint(2, 3)
        body_sentences = (random.choices(content["sentences"], k=n_primary) +
                          random.choices(CATEGORY_CONTENT[secondary_category]["sentences"], k=n_secondary))
        random.shuffle(body_sentences)
    else:
        n_sentences = random.randint(4, 7)
        body_sentences = random.choices(content["sentences"], k=n_sentences)

    # Shared boilerplate that appears across ALL categories — makes the task
    # non-trivial by diluting each document with category-neutral language.
    n_boilerplate = random.randint(1, 3)
    for _ in range(n_boilerplate):
        body_sentences.insert(random.randint(0, len(body_sentences)), random.choice(SHARED_BOILERPLATE))

    # Cross-category noise: 1-2 extra sentences borrowed from a different
    # category (applied on top of the ambiguous mix too, for realism).
    if random.random() < 0.35:
        n_noise = random.randint(1, 2)
        for _ in range(n_noise):
            other_category = random.choice([c for c in CATEGORY_CONTENT if c != category])
            body_sentences.insert(
                random.randint(0, len(body_sentences)),
                random.choice(CATEGORY_CONTENT[other_category]["sentences"])
            )

    doc_id_str = f"DOC_{doc_id:04d}"
    title = f"{doc_type} — {fake.date_between(start_date='-180d', end_date='today').strftime('%B %d, %Y')}"

    pdf_path = PDF_DIR / f"{doc_id_str}.pdf"
    doc = SimpleDocTemplate(str(pdf_path), pagesize=letter,
                             topMargin=0.8*inch, bottomMargin=0.8*inch)
    elements = [
        Paragraph(title, styles["Title"]),
        Spacer(1, 0.2*inch),
        Paragraph(f"Prepared by: {fake.name()}  |  Department: {fake.job()[:30]}", styles["Normal"]),
        Spacer(1, 0.3*inch),
    ]
    for sent in body_sentences:
        elements.append(Paragraph(sent, styles["BodyText"]))
        elements.append(Spacer(1, 0.12*inch))
    doc.build(elements)

    rows.append({"doc_id": doc_id_str, "true_category": category, "doc_type": doc_type,
                 "pdf_path": str(pdf_path), "is_ambiguous": is_ambiguous,
                 "secondary_category": secondary_category})
    doc_id += 1

labels_df = pd.DataFrame(rows)
labels_df.to_csv("/home/claude/doc_risk_classifier/data/labels.csv", index=False)

print(f"Generated {len(labels_df)} PDF documents in {PDF_DIR}")
print(labels_df["true_category"].value_counts())
