"""
AI Document Risk & Compliance Classifier — full pipeline.

Steps:
 1. Collect sample documents (real PDFs) with risk/compliance category labels
 2. Extract text from PDFs and remove irrelevant formatting/whitespace
 3. Generate TF-IDF features and train a multiclass classifier
 4. Add explainability: top important terms per class + nearest similar
    documents for any given document
 5. Set a confidence threshold so uncertain cases go to manual review
 6. Evaluate class-wise performance and save everything the dashboard needs

Run: python train_classifier.py
"""

import re
import json
import joblib
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from pathlib import Path
from pypdf import PdfReader

from sklearn.model_selection import train_test_split
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import classification_report, f1_score, ConfusionMatrixDisplay
from sklearn.metrics.pairwise import cosine_similarity

DATA_DIR = Path("/home/claude/doc_risk_classifier/data")
OUT_DIR = Path("/home/claude/doc_risk_classifier/outputs")
MODEL_DIR = Path("/home/claude/doc_risk_classifier/models")
OUT_DIR.mkdir(exist_ok=True)
MODEL_DIR.mkdir(exist_ok=True)

RANDOM_STATE = 42
LOW_CONFIDENCE_THRESHOLD = 0.55  # below this, a document is routed to manual review

# ---------------------------------------------------------------
# 1. LOAD LABELS
# ---------------------------------------------------------------
labels_df = pd.read_csv(DATA_DIR / "labels.csv")
print(f"Loaded {len(labels_df)} labeled documents across {labels_df['true_category'].nunique()} categories")

# ---------------------------------------------------------------
# 2. EXTRACT TEXT FROM PDFs + CLEAN FORMATTING
# ---------------------------------------------------------------
def extract_pdf_text(pdf_path: str) -> str:
    """Extracts raw text from a PDF using pypdf."""
    reader = PdfReader(pdf_path)
    return "\n".join(page.extract_text() or "" for page in reader.pages)


def clean_text(text: str) -> str:
    """Removes PDF extraction artifacts: extra whitespace, page-break noise, non-content characters."""
    text = text.lower()
    text = re.sub(r"[\r\n]+", " ", text)              # collapse line breaks from PDF layout
    text = re.sub(r"[^a-z0-9\s.,%$]", " ", text)       # strip stray symbols/bullets from extraction
    text = re.sub(r"\s+", " ", text).strip()
    return text


print("Extracting text from PDFs...")
extracted_texts = []
for _, row in labels_df.iterrows():
    raw_text = extract_pdf_text(row["pdf_path"])
    extracted_texts.append(clean_text(raw_text))

labels_df["text"] = extracted_texts
labels_df = labels_df[labels_df["text"].str.len() > 20].reset_index(drop=True)
print(f"Text extracted and cleaned for {len(labels_df)} documents")
print("Sample cleaned text:", labels_df.iloc[0]["text"][:150], "...")

# Save extracted text alongside labels so the dashboard can reuse it for
# nearest-neighbor lookups without re-parsing every PDF at runtime.
labels_df.to_csv(OUT_DIR / "documents_with_text.csv", index=False)

# ---------------------------------------------------------------
# 3. TRAIN / TEST SPLIT + TF-IDF FEATURES
# ---------------------------------------------------------------
train_df, test_df = train_test_split(
    labels_df, test_size=0.2, random_state=RANDOM_STATE, stratify=labels_df["true_category"]
)
print(f"Train: {len(train_df):,} | Test: {len(test_df):,}")

vectorizer = TfidfVectorizer(max_features=3000, ngram_range=(1, 2), stop_words="english", min_df=2)
X_train = vectorizer.fit_transform(train_df["text"])
X_test = vectorizer.transform(test_df["text"])

# ---------------------------------------------------------------
# 4. TRAIN THE CLASSIFIER
# ---------------------------------------------------------------
y_train = train_df["true_category"]
y_test = test_df["true_category"]

model = LogisticRegression(max_iter=1000, class_weight="balanced", random_state=RANDOM_STATE)
model.fit(X_train, y_train)

y_pred = model.predict(X_test)
y_proba = model.predict_proba(X_test)
confidence = y_proba.max(axis=1)

f1_macro = f1_score(y_test, y_pred, average="macro")
f1_weighted = f1_score(y_test, y_pred, average="weighted")
print(f"\n=== CLASSIFIER PERFORMANCE ===")
print(f"Macro F1: {f1_macro:.3f} | Weighted F1: {f1_weighted:.3f}")
print(classification_report(y_test, y_pred))

class_report = classification_report(y_test, y_pred, output_dict=True)
pd.DataFrame(class_report).T.to_csv(OUT_DIR / "classification_report.csv")

# Confusion matrix
fig, ax = plt.subplots(figsize=(7, 6))
ConfusionMatrixDisplay.from_predictions(
    y_test, y_pred, labels=model.classes_, cmap="Purples", ax=ax, colorbar=False,
    xticks_rotation=20,
)
ax.set_title("Document Risk Classifier — Confusion Matrix")
plt.tight_layout()
plt.savefig(OUT_DIR / "confusion_matrix.png", dpi=150)
plt.close()

# Per-class precision/recall/F1
fig, ax = plt.subplots(figsize=(9, 5))
class_df = pd.DataFrame(class_report).T.loc[model.classes_, ["precision", "recall", "f1-score"]]
class_df.plot(kind="bar", ax=ax, color=["#5B4B8A", "#02C39A", "#D9704F"])
ax.set_title("Per-Class Precision / Recall / F1")
ax.set_ylim(0, 1)
ax.tick_params(axis="x", rotation=15)
plt.tight_layout()
plt.savefig(OUT_DIR / "per_class_metrics.png", dpi=150)
plt.close()

# ---------------------------------------------------------------
# 5. EXPLAINABILITY — TOP TERMS PER CLASS
# ---------------------------------------------------------------
feature_names = np.array(vectorizer.get_feature_names_out())
top_terms_per_class = {}
for i, cls in enumerate(model.classes_):
    top_idx = np.argsort(model.coef_[i])[-12:][::-1]
    top_terms_per_class[cls] = feature_names[top_idx].tolist()

with open(OUT_DIR / "top_terms_per_class.json", "w") as f:
    json.dump(top_terms_per_class, f, indent=2)

print("\n=== TOP TERMS PER CATEGORY (explainability) ===")
for cls, terms in top_terms_per_class.items():
    print(f"{cls}: {', '.join(terms[:8])}")

# ---------------------------------------------------------------
# EXPLAINABILITY — NEAREST SIMILAR DOCUMENTS (for any test doc)
# ---------------------------------------------------------------
def nearest_similar_docs(doc_index_in_test: int, top_k: int = 3):
    """Returns the top_k most similar training documents to a given test document (by TF-IDF cosine similarity)."""
    sims = cosine_similarity(X_test[doc_index_in_test], X_train).flatten()
    top_idx = np.argsort(sims)[-top_k:][::-1]
    return train_df.iloc[top_idx][["doc_id", "true_category", "doc_type"]].assign(similarity=sims[top_idx].round(3))

# Demo on the first test document
demo_neighbors = nearest_similar_docs(0)
print(f"\nExample — nearest similar documents to {test_df.iloc[0]['doc_id']} "
      f"({test_df.iloc[0]['true_category']}):")
print(demo_neighbors.to_string(index=False))

# ---------------------------------------------------------------
# 6. CONFIDENCE THRESHOLD -> MANUAL REVIEW QUEUE
# ---------------------------------------------------------------
review_mask = confidence < LOW_CONFIDENCE_THRESHOLD
review_queue = test_df.loc[review_mask, ["doc_id", "doc_type", "true_category"]].copy()
review_queue["predicted_category"] = y_pred[review_mask]
review_queue["confidence"] = confidence[review_mask].round(3)
review_queue.to_csv(OUT_DIR / "manual_review_queue.csv", index=False)

print(f"\n{len(review_queue)} of {len(test_df)} test documents "
      f"({len(review_queue)/len(test_df)*100:.1f}%) flagged for manual review "
      f"(confidence < {LOW_CONFIDENCE_THRESHOLD})")

# Confidence distribution chart
fig, ax = plt.subplots(figsize=(8, 5))
ax.hist(confidence, bins=20, color="#5B4B8A", edgecolor="white")
ax.axvline(LOW_CONFIDENCE_THRESHOLD, color="#D9704F", linestyle="--", linewidth=2,
           label=f"Review threshold ({LOW_CONFIDENCE_THRESHOLD})")
ax.set_title("Prediction Confidence Distribution")
ax.set_xlabel("Confidence")
ax.set_ylabel("Number of Documents")
ax.legend()
plt.tight_layout()
plt.savefig(OUT_DIR / "confidence_distribution.png", dpi=150)
plt.close()

# ---------------------------------------------------------------
# SAVE MODELS + PREDICTIONS FOR THE DASHBOARD
# ---------------------------------------------------------------
joblib.dump(vectorizer, MODEL_DIR / "vectorizer.joblib")
joblib.dump(model, MODEL_DIR / "classifier.joblib")

full_predictions = test_df[["doc_id", "doc_type", "true_category", "pdf_path"]].copy()
full_predictions["predicted_category"] = y_pred
full_predictions["confidence"] = confidence.round(3)
full_predictions["flagged_for_review"] = review_mask
full_predictions.to_csv(OUT_DIR / "all_predictions.csv", index=False)

summary = {
    "macro_f1": round(f1_macro, 3),
    "weighted_f1": round(f1_weighted, 3),
    "low_confidence_threshold": LOW_CONFIDENCE_THRESHOLD,
    "pct_flagged_for_review": round(len(review_queue) / len(test_df) * 100, 1),
    "train_size": len(train_df),
    "test_size": len(test_df),
    "total_documents": len(labels_df),
    "categories": list(model.classes_),
}
with open(OUT_DIR / "model_summary.json", "w") as f:
    json.dump(summary, f, indent=2)

print("\nModels saved to:", MODEL_DIR)
print("Evaluation outputs saved to:", OUT_DIR)
print(json.dumps(summary, indent=2))
