# AI Document Risk & Compliance Classifier

**Capstone Project — Mindenious Edutech Data Science Program**

## Objective
Automatically classify business documents into risk/compliance categories and flag documents that may need manual review.

## Project Structure
```
doc_risk_classifier/
├── data/
│   ├── generate_documents.py   # generates 500 REAL synthetic PDF documents
│   ├── pdfs/                   # DOC_0001.pdf ... DOC_0500.pdf
│   └── labels.csv              # doc_id, true_category, doc_type, pdf_path
├── notebooks/
│   └── train_classifier.py     # extract -> clean -> TF-IDF -> train -> explainability -> evaluate
├── dashboard/
│   └── app.py                  # Streamlit app: classify + explainability + review queue
├── models/
│   ├── vectorizer.joblib
│   └── classifier.joblib
├── outputs/
│   ├── documents_with_text.csv
│   ├── classification_report.csv
│   ├── confusion_matrix.png
│   ├── per_class_metrics.png
│   ├── confidence_distribution.png
│   ├── top_terms_per_class.json
│   ├── manual_review_queue.csv
│   ├── all_predictions.csv
│   └── model_summary.json
├── requirements.txt
└── README.md
```

## How to Run
```bash
pip install -r requirements.txt

# 1. Generate 500 synthetic business documents as real PDFs
python data/generate_documents.py

# 2. Extract text, clean, train, explain, evaluate
python notebooks/train_classifier.py

# 3. Launch the dashboard
streamlit run dashboard/app.py
```

## Approach (mapped to the brief)
1. **Collect sample documents & define categories** — `generate_documents.py` produces 500 real PDF files across four categories: **Low Risk** (newsletters, announcements), **Medium Risk** (vendor agreements, HR policies, NDAs), **High Risk** (audit reports, data-incident reports, legal disputes), and **Critical/Regulatory** (regulatory filings, AML/KYC reports, breach notifications). ~15% of documents are deliberately **ambiguous** — built from a genuine 50/50 mix of two categories' language — plus shared boilerplate and cross-category noise sentences, so the classification problem is realistically hard rather than trivially separable.
2. **Extract text & remove formatting** — `extract_pdf_text()` uses `pypdf` to pull raw text from each PDF; `clean_text()` then lowercases, collapses line-break/whitespace artifacts from the PDF layout, and strips stray extraction symbols.
3. **Features + classifier** — TF-IDF (unigrams + bigrams, 3,000 features) feeds a class-balanced multiclass `LogisticRegression`.
4. **Explainability** — two forms, both saved for the dashboard: (a) the top 12 TF-IDF terms driving each category's predictions, pulled straight from the model's coefficients, and (b) a `nearest_similar_docs()` function that returns the most cosine-similar training documents to any given document, so a reviewer can see *why* the model made a call.
5. **Confidence threshold → manual review** — any prediction below 0.55 confidence is routed to `manual_review_queue.csv` instead of auto-classified.
6. **Evaluation + dashboard** — class-wise precision/recall/F1 and a confusion matrix are computed and charted; the Streamlit dashboard lets you upload a PDF and see its classification, confidence breakdown by category, explainability (top terms + nearest documents), and a second tab listing every flagged document from the test set.

## Results (on the generated sample data — 500 documents, 4 categories)
| Metric | Score |
|---|---|
| Macro F1 | 0.99 |
| Weighted F1 | 0.99 |
| Documents flagged for manual review | 6.0% |

- **Near-perfect but not artificially perfect** — the one confusion (a Low Risk document predicted as Medium Risk) and the 6% review-queue rate both come from the intentionally ambiguous documents, which is the realistic failure mode this system is designed to catch rather than hide.
- **Explainability holds up under inspection** — top terms per category are exactly what a compliance reviewer would expect (e.g. "regulatory, compliance, requirements" for Critical/Regulatory; "dispute, financial, audit" for High Risk), which is what makes the flagged-document review actually useful rather than a black box.

## Data Note
As with the other capstone projects, no proprietary business documents were available, so this uses **synthetically generated documents — as real PDF files**, not just text, so the "extract text from PDFs" step in the brief is genuinely exercised rather than skipped. To adapt this to real documents, drop real PDFs into `data/pdfs/` with a matching `labels.csv` (or run the trained model directly on unlabeled PDFs via the dashboard's upload tab).

## Suggested Stack (per brief)
- **Python** (pandas, scikit-learn, pypdf) for extraction, cleaning, and modeling
- **TF-IDF** for text features, with per-class coefficient inspection and cosine-similarity nearest neighbors for explainability
- **Streamlit** for the classification + review dashboard
- **Git/GitHub** for version control
